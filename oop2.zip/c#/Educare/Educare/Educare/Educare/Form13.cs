﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;

namespace Educare
{
    public partial class Form13 : Form
    {
        //CS CONNECTION STRING
        string cs = ConfigurationManager.ConnectionStrings["APPS"].ConnectionString;
        public Form13()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text) == true)
            {
                textBox1.Focus();
                errorProvider1.SetError(this.textBox1, "Please fill the field first");
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox2.Text) == true)
            {
                textBox1.Focus();
                errorProvider2.SetError(this.textBox2, "Please fill the field first");
            }
            else
            {
                errorProvider2.Clear();
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox3.Text) == true)
            {
                textBox1.Focus();
                errorProvider3.SetError(this.textBox3, "Please fill the field first");
            }
            else
            {
                errorProvider3.Clear();
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox5.Text) == true)
            {
                textBox5.Focus();
                errorProvider5.SetError(this.textBox1, "Please fill the field first");
            }
            else
            {
                errorProvider5.Clear();
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text) == true)
            {
                textBox4.Focus();
                errorProvider4.SetError(this.textBox4, "Please fill the field first");
            }
            else
            {
                errorProvider4.Clear();
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            bool status = checkBox1.Checked;
            switch (status)
            {
                case true:
                    textBox4.UseSystemPasswordChar = false;
                    break;
                default:
                    textBox4.UseSystemPasswordChar = true;
                    break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Select Image";
            ofd.Filter = "Image File (All files) *.* | *.*";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = new Bitmap(ofd.FileName);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "" && textBox2.Text == textBox3.Text && textBox5.Text == textBox4.Text)
            {
                SqlConnection con = new SqlConnection(cs);
                string query = " Insert into REGISTRATIONDATA2_TABLE values (@username,@email,@password,@picture) ";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@username", textBox1.Text);
                cmd.Parameters.AddWithValue("@email", textBox2.Text);
                cmd.Parameters.AddWithValue("@password", textBox4.Text);
                cmd.Parameters.AddWithValue("@picture", Savephoto());

                con.Open();
                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {
                    MessageBox.Show("Registration Successfull", "Success", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                    this.Hide();
                    Form7 f7 = new Form7();
                    f7.Show();
                }
                else
                {
                    MessageBox.Show("Registration Failed", "Failed", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                }


                con.Close();

            }
            else
            {
                if (textBox2.Text != textBox3.Text)
                {
                    label8.Visible = true;
                    if (textBox5.Text != textBox4.Text)
                    {
                        label9.Visible = true;
                    }
                }
                else if (textBox5.Text != textBox4.Text)
                {
                    label9.Visible = true;
                }
                else
                {
                    MessageBox.Show("Please Fill every Fields First!", "Failed", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                }

            }
        }

        private byte[] Savephoto()
        {
            MemoryStream ms = new MemoryStream();
            pictureBox1.Image.Save(ms, pictureBox1.Image.RawFormat);
            return ms.GetBuffer();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form7 f7 = new Form7();
            f7.Show();
        }
    }
}
