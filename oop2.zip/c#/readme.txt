##EDUCARE


    EDUCARE  management system  is designed and developed for faculty and students. EDUCARE system helps studentso that they  can easily give their exam and Faculty 
    also show answer paper . 


##Tools Used
   


          To develop this project , the following tools  were used :
         
             -> Microsoft Visual Studio 2019 Community Edition 
          
             -> Microsoft SQL Server 2014 EXpress 
   






##Installation 
   

     Use sql server query ,   "EDUCARE_APP" to create database .

     After creating database , replace the connection string from appconfig .

    

  
 ##Intial Login Credential 
  
From the Login Form click " Login as Admin " first , then use below credentials .

   *Private property : Educare
   * Password :123

  After a successful login ,then Faculty details show . After that next form is open and that is student details . 
Then back again faculity details and logout option .
  
   
  
     
    
From the Login Form click " Login as Student " first , then use below credentials .

   *Private property : Rahul Raj
   * Password :123456

  After a successful login ,then Subject details show . After that next form is open and that is Submit details form  . Then back again Subject details and here found 
  logout option .





From the Login Form click " Login as Faculty " first , then use below credentials .


*Private property : Md Nazmul hossain
   * Password :12345

  After a successful login ,student detail show.After that next form is open and that is subject details and next form is student submit detail.Then back again subject 
   details and found logout option  . 


-- Support 
    1.sithishikder22@gmail.com 
    2.rahul.jr2016@gmail.com
    3.arponmonda1999@gmail.com


  Enjoy this software .
  THANK YOU !


